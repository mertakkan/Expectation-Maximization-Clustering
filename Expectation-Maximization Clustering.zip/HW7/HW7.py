#!/usr/bin/env python
# coding: utf-8

# In[2]:


#!/usr/bin/env python
# coding: utf-8

# In[203]:


import matplotlib.pyplot as plt
import numpy as np
import scipy.spatial as spa
from scipy.stats import multivariate_normal
import math
import pandas as pd
from math import e
from math import pow


# In[204]:


np.random.seed(421)
N = 300
K = 5


mean1 = np.array([2.5, 2.5])
mean2 = np.array([-2.5, 2.5])
mean3 = np.array([-2.5, -2.5])
mean4 = np.array([+2.5, -2.5])
mean5 = np.array([0, 0])

cov1 = np.array([[0.8, -0.6], [-0.6, 0.8]])
cov2 = np.array([[0.8, 0.6], [0.6, 0.8]])
cov3 = np.array([[0.8, -0.6], [-0.6, 0.8]])
cov4 = np.array([[0.8, 0.6], [0.6, 0.8]])
cov5 = np.array([[1.6, 0], [0, 1.6]])

num1 = 50
num2 = 50
num3 = 50
num4 = 50
num5 = 100

class_sizes = np.array([num1, num2, num3, num4, num5])
class_means = np.array([mean1, mean2, mean3, mean4, mean5])
class_covariances = np.array([cov1, cov2, cov3, cov4, cov5])

X = np.genfromtxt("hw07_data_set.csv", delimiter = ",")


# In[205]:


plt.scatter(X[:,0], X[:,1],s=None, c="black")
plt.axis([-5, 5, -5, 5])
plt.xlabel('x1')
plt.ylabel('x2')
plt.show()


# In[206]:


def plot_current_state(centroids, memberships, X):
    cluster_colors = np.array(["#1f78b4", "#33a02c", "#e31a1c", "#ff7f00", "#6a3d9a", "#b15928",
                               "#a6cee3", "#b2df8a", "#fb9a99", "#fdbf6f", "#cab2d6", "#ffff99"])
    if memberships is None:
        plt.plot(X[:,0], X[:,1], ".", markersize = 10, color = "black")
    else:
        for c in range(K):
            plt.plot(X[memberships == c, 0], X[memberships == c, 1], ".", markersize = 10,
                     color = cluster_colors[c])
    for c in range(K):
        plt.plot(centroids[c, 0], centroids[c, 1], "s", markersize = 12, 
                 markerfacecolor = cluster_colors[c], markeredgecolor = "black")
    plt.xlabel("x1")
    plt.ylabel("x2")


# In[207]:


def update_centroids(memberships, X):
    if memberships is None:
        centroids = np.genfromtxt("hw07_initial_centroids.csv", delimiter = ",")
    else:
        centroids = np.vstack([np.mean(X[memberships == k,], axis = 0) for k in range(K)])
    return(centroids)

def update_memberships(centroids, X):
    D = spa.distance_matrix(centroids, X)
    memberships = np.argmin(D, axis = 0)
    return(memberships)


# In[208]:


centroids = None
memberships = None
iteration = 1
while True:
    old_centroids = centroids
    centroids = update_centroids(memberships, X)
    if np.alltrue(centroids == old_centroids):
        break
        

    old_memberships = memberships
    memberships = update_memberships(centroids, X)
    if np.alltrue(memberships == old_memberships):
        break

    iteration = iteration + 1


# In[209]:


points = [[], [], [], [], []]
for i in range(len(memberships)):
    points[memberships[i]].append(X[i])

init_priors = []
init_covariances = []
for group in points:
    init_covariances.append(np.cov(np.asmatrix(group).T))
    init_priors.append(len(group) / len(memberships))

h = np.zeros((300, 5))
priors = init_priors
covariances = init_covariances
XMATRIX = np.asmatrix(X)

def EM(priors, covariances, centroids):
    for i in range(0, 100):
        for k in range(0, 300):
            sum = 0
            for j in range(0, 5):
                xmatrix = np.matrix([X[k] - centroids[j]])
                mat = xmatrix.dot(np.linalg.inv(covariances[j])).dot(xmatrix.T)
                mat = mat * (-.5)
                h[k][j] = priors[j] * pow(np.linalg.det(covariances[j]), -0.5) * pow(e, mat[0])
                sum += h[k][j]
            h[k] /= sum
    return h

centroids = EM(priors, covariances, centroids).T.dot(XMATRIX)
hSum = np.sum(h, axis=0)
centroids = centroids / hSum[:, None]
centroids = np.asarray(centroids)
covariances = []

for j in range(0, 5):
    sum = 0
    for k in range(0, 300):
        xmatrix = np.matrix([X[k] - centroids[j]])
        mat = xmatrix.T.dot(xmatrix)
        res = mat * h[k][j]
        sum += res
    sum /= hSum[j]
    covariances.append(sum)

print(centroids)

memberships = update_memberships(centroids, X)
plot_current_state(centroids, memberships, X)

a, b = np.mgrid[-5:5:0.05, -5:5:0.05]
pos = np.empty(a.shape + (2,))
pos[:, :, 0] = a
pos[:, :, 1] = b

colors = ["#1f78b4", "#33a02c", "#e31a1c", "#ff7f00", "#6a3d9a", "#b15928",
                               "#a6cee3", "#b2df8a", "#fb9a99", "#fdbf6f", "#cab2d6", "#ffff99"]
for i in range(0, 5):
    lines = multivariate_normal(class_means[i], class_covariances[i])
    plt.contour(a, b, lines.pdf(pos), linestyles='dashed', levels=[0.05], colors='k')
    lines = multivariate_normal(centroids[i], covariances[i])
    plt.contour(a, b, lines.pdf(pos), colors='k', levels=[0.05])
    
plt.show()

